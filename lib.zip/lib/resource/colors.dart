

import 'package:flutter/material.dart';

const Color greyColor = Color(0xff707070);
const Color blueColor = Color(0xffBC7DC0); // pink
const Color goldColor = Color(0xffFAB800);